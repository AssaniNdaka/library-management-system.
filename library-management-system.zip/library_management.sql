-- library_management.sql
-- Library Management System Database
-- Author: Assani Ndaka
-- Date: 2025-08-11

-- DROP tables if exist to avoid errors on rerun
DROP TABLE IF EXISTS BookAuthors;
DROP TABLE IF EXISTS Loans;
DROP TABLE IF EXISTS Books;
DROP TABLE IF EXISTS Authors;
DROP TABLE IF EXISTS Members;
DROP TABLE IF EXISTS Categories;
DROP TABLE IF EXISTS Staff;

-- Create Categories table (1-M with Books)
CREATE TABLE Categories (
    CategoryID INT AUTO_INCREMENT PRIMARY KEY,
    CategoryName VARCHAR(100) NOT NULL UNIQUE
);

-- Create Authors table
CREATE TABLE Authors (
    AuthorID INT AUTO_INCREMENT PRIMARY KEY,
    FirstName VARCHAR(50) NOT NULL,
    LastName VARCHAR(50) NOT NULL
);

-- Create Books table
CREATE TABLE Books (
    ISBN VARCHAR(13) PRIMARY KEY,  -- ISBN-13 as PK
    Title VARCHAR(200) NOT NULL,
    Publisher VARCHAR(100),
    YearPublished YEAR,
    CategoryID INT NOT NULL,
    CONSTRAINT fk_Category FOREIGN KEY (CategoryID) REFERENCES Categories(CategoryID)
        ON DELETE RESTRICT ON UPDATE CASCADE
);

-- Many-to-Many relationship between Books and Authors
CREATE TABLE BookAuthors (
    ISBN VARCHAR(13),
    AuthorID INT,
    PRIMARY KEY (ISBN, AuthorID),
    CONSTRAINT fk_Book FOREIGN KEY (ISBN) REFERENCES Books(ISBN)
        ON DELETE CASCADE ON UPDATE CASCADE,
    CONSTRAINT fk_Author FOREIGN KEY (AuthorID) REFERENCES Authors(AuthorID)
        ON DELETE CASCADE ON UPDATE CASCADE
);

-- Create Members table
CREATE TABLE Members (
    MemberID INT AUTO_INCREMENT PRIMARY KEY,
    FirstName VARCHAR(50) NOT NULL,
    LastName VARCHAR(50) NOT NULL,
    Email VARCHAR(100) NOT NULL UNIQUE,
    Phone VARCHAR(20),
    MembershipDate DATE NOT NULL DEFAULT CURRENT_DATE
);

-- Create Staff table
CREATE TABLE Staff (
    StaffID INT AUTO_INCREMENT PRIMARY KEY,
    FirstName VARCHAR(50) NOT NULL,
    LastName VARCHAR(50) NOT NULL,
    Email VARCHAR(100) NOT NULL UNIQUE,
    Position VARCHAR(50)
);

-- Create Loans table (tracks book borrowing)
CREATE TABLE Loans (
    LoanID INT AUTO_INCREMENT PRIMARY KEY,
    ISBN VARCHAR(13) NOT NULL,
    MemberID INT NOT NULL,
    LoanDate DATE NOT NULL DEFAULT CURRENT_DATE,
    ReturnDate DATE,
    Returned BOOLEAN NOT NULL DEFAULT FALSE,
    CONSTRAINT fk_LoanBook FOREIGN KEY (ISBN) REFERENCES Books(ISBN)
        ON DELETE RESTRICT ON UPDATE CASCADE,
    CONSTRAINT fk_LoanMember FOREIGN KEY (MemberID) REFERENCES Members(MemberID)
        ON DELETE CASCADE ON UPDATE CASCADE
);
