# Library Management System - MySQL Database

## Project Description
This project implements a complete relational database for a **Library Management System** using MySQL.  
It models the core aspects of a library including:

- Managing **Books** with their ISBN, title, publisher, year, and category.
- Tracking **Authors** who can write multiple books (many-to-many relationship).
- Maintaining **Members** who borrow books.
- Recording **Loans** to track which member borrowed which book and the return status.
- Categorizing books into **Categories**.
- Managing **Staff** information.

The database schema is designed with appropriate primary keys, foreign keys, and constraints to ensure data integrity and reflect real-world relationships.

---

## Setup Instructions

1. **Install MySQL** if you haven’t already.  
   You can download it from: [https://dev.mysql.com/downloads/mysql/](https://dev.mysql.com/downloads/mysql/)

2. **Create a new database/schema**  
   Open MySQL Workbench or your preferred MySQL client and run:  
   ```sql
   CREATE DATABASE library_db;
   USE library_db;
   ```

3. **Import the SQL file**  
   Run the `library_management.sql` script to create all tables and constraints. For example, in MySQL Workbench, open the file and execute it.

4. **(Optional) Insert sample data** to test the database (sample inserts are not included but can be added).

---

## Entity Relationship Diagram (ERD)

Since the ERD image is not included, here is a textual summary of the main relationships:  

- One **Category** can have many **Books** (1-to-many).  
- A **Book** can have many **Authors** and an **Author** can write many **Books** (many-to-many via BookAuthors table).  
- A **Member** can have many **Loans** (1-to-many). Each **Loan** references one **Book** and one **Member**.

---

## Files in this repository

- `library_management.sql` — Contains all SQL commands to create tables and constraints.
- `README.md` — This file with project details and setup instructions.

---

## Author

Assani Ndaka  
Date: August 2025

---

## License

This project is licensed under the MIT License.
